# VDock Virtual Stream Deck - Distribution Package

This is a complete distribution package of VDock that includes everything needed to run the application.

## What's Included

- **VDock-Launcher.exe**: Standalone executable launcher (if available)
- **Backend**: Python Flask server with all dependencies
- **Frontend**: Vue.js web application (pre-built)
- **Documentation**: Complete user guides and API documentation
- **Launch Scripts**: Easy-to-use startup scripts

## System Requirements

- **Windows 10/11** (recommended)
- **Python 3.8+** - Download from https://python.org
- **Node.js 16+** - Download from https://nodejs.org
- **4GB RAM** minimum
- **1GB free disk space**

## Quick Start

### Option 1: Using the Executable Launcher (Easiest)
1. Double-click `VDock-Launcher.exe`
2. Wait for the application to start
3. VDock will open automatically in your browser

### Option 2: Using Launch Script
1. Double-click `launch.bat`
2. Wait for dependencies to install (first run only)
3. VDock will open automatically in your browser

### Option 3: Manual Setup
1. Run `install.bat` to install dependencies
2. Run `launch.bat` to start the application

## First Time Setup

1. **Install Dependencies**: The first run will automatically install all required dependencies
2. **Login**: Use the default credentials (admin/admin) or set up authentication
3. **Create Profile**: Set up your first button profile
4. **Add Buttons**: Start adding buttons to your virtual stream deck

## Default Access URLs

- **Main Application**: http://localhost:3000
- **Backend API**: http://localhost:5000

## Troubleshooting

### Common Issues

**Python not found**
- Install Python from https://python.org
- Make sure to check "Add Python to PATH" during installation

**Node.js not found**
- Install Node.js from https://nodejs.org
- Restart your command prompt after installation

**Ports already in use**
- Close other applications using ports 3000 or 5000
- Or modify the port settings in the configuration files

**Permission errors**
- Run as Administrator if you encounter permission issues
- Check your antivirus software settings

### Getting Help

- Check the `docs` folder for detailed documentation
- Visit the project repository for updates and support
- Review the log files in the `data` folder for error details

## Features

- **Virtual Stream Deck**: Create custom button layouts
- **Multiple Profiles**: Switch between different button configurations
- **Action Types**: Support for various actions (commands, hotkeys, URLs, etc.)
- **Themes**: Customize the appearance
- **Plugins**: Extend functionality with custom plugins
- **Web-based**: Access from any modern web browser
- **Cross-platform**: Works on Windows, macOS, and Linux

## Security Notes

- VDock runs locally on your machine
- No data is sent to external servers
- Authentication can be configured for additional security
- All data is stored locally in the `data` folder

---

**Enjoy using VDock**

For more information, visit the documentation in the `docs` folder.
