@echo off
echo ========================================
echo VDock Virtual Stream Deck
echo ========================================
echo.

REM Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    echo Please install Python 3.8+ from https://python.org
    echo.
    pause
    exit /b 1
)

REM Check for Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo Error: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org
    echo.
    pause
    exit /b 1
)

echo ✓ Python found
echo ✓ Node.js found
echo.

REM Install Python dependencies if needed
if not exist "backend\venv" (
    echo Installing Python dependencies...
    cd backend
    python -m venv venv
    call venv\Scripts\activate
    pip install -r requirements.txt
    cd ..
    echo ✓ Python dependencies installed
) else (
    echo ✓ Python dependencies already installed
)

REM Install Node.js dependencies if needed
if not exist "frontend\node_modules" (
    echo Installing Node.js dependencies...
    cd frontend
    npm install
    cd ..
    echo ✓ Node.js dependencies installed
) else (
    echo ✓ Node.js dependencies already installed
)

echo Starting VDock services...
echo.

REM Start backend server
echo Starting backend server...
start "VDock Backend" cmd /k "cd backend ^&^& call venv\Scripts\activate ^&^& python app.py"

REM Wait a moment for backend to start
timeout /t 3 /nobreak >nul

REM Start frontend server
echo Starting frontend server...
start "VDock Frontend" cmd /k "cd frontend ^&^& npm run dev"

REM Wait for servers to start
echo Waiting for servers to start...
timeout /t 5 /nobreak >nul

REM Open browser
echo Opening VDock in browser...
start http://localhost:3000

echo ========================================
echo VDock Started Successfully
echo ========================================
echo.
echo Backend:  http://localhost:5000
echo Frontend: http://localhost:3000
echo.
echo Default login:
echo   Username: admin
echo   Password: admin
echo.
echo Both servers are running in the background.
echo Close the server windows to stop VDock.
echo.
pause
